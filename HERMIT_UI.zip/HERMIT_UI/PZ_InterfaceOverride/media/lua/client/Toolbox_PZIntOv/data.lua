
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================
-- File [ data.lua ] : Save and Load Mod Data

-- Inventory [ .../data.lua ]
-- 1. Data.key_value_pattern ; string patter to be used with match function
-- 2. Data.end_line_string ; windows end line string
-- ------------------- Variables | Functions --------------------------
-- 1. Data.getKeyValueFromString(content_string)
-- 2. Data.isInGame()
-- 3. Data.saveTableDictionary(table_dict, filename)
-- 4. Data.loadTableDictionary(filename)
-- 5. Data.regTableData(name)
-- 6. Data.resetTableData(name)
-- 7. Data.getGameSaveDir()
-- 8. Data.init( inner_function )
-- --------------------------- LIB | VANILLA --------------------------
-- 1. local reader = getFileReader("FILENAME.EXT", false)e)
-- 2. reader:close()
-- 3. local key, value = LINE:match( PATTERN )
-- 4. local writer = getFileWriter("FILENAME.EXT", true, false)
-- 5. writer:write(content_string)
-- 6. writer:close()
-- 7. ModData.remove(TABLE_NAME)
-- 8. local TABLE_VAR = ModData.getOrCreate(TABLE_NAME)
-- 9. ISOPLAYER:save(FILENAME)
-- 10. ISOPLAYER:load(FILENAME)
-- 11. ISOPLAYER:getModData().survivorID
-- 12. ISOPLAYER:getModData()
-- local PARENT_DIR = PLS DEFINE ME !!!
-- local Data = require(PARENT_DIR.."data")

local Data = {}

-- 
-- ====================================================================
-- Logic from ... | Constructed from ... { Mod Options }

Data.key_value_pattern = "^([^=%[]+)=([^=]+)$"
Data.end_line_string = "/r/n"

function Data.getKeyValueFromString(content_string) -- [testing]
    local k,v = content_string:match( Data.key_value_pattern )
    return k,v
end

function Data.isInGame() -- [testing]
    return MainScreen.instance.inGame
end

function Data.saveTableDictionary(table_dict, filename) -- [testing]
    local writer = getFileWriter(filename, true, false)
    for key,value in pairs(table_dict) do 
        writer:write(key..' = '..tostring(value)..Data.end_line_string)
    end
    writer:close()
end

function Data.loadTableDictionary(filename) -- [testing]
    local loaded_table = {}
    local reader = getFileReader(filename, false)
    if not reader then return nil end
    while true do 
        local line = reader:readLine()
        if not line then reader:close() ; break end
        line = line:trim()
        if line ~= "" then
            local k,v = line:match( Data.key_value_pattern )
            if k then 
                loaded_table[k:trim()] = v:trim()
            end
        end
    end
    reader:close()
    return loaded_table
end

-- 
-- ====================================================================
-- Logic from ... | Constructed from ... { PZNS NPC Framework }

function Data.regTableData(name) -- [ok]
    -- the table returned is saved automatically 
    return ModData.getOrCreate(name)
end

function Data.resetTableData(name) -- [verified]
    ModData.remove(name)
end

function Data.getGameSaveDir() -- [ok]
    -- from pzns
    local stringPath = tostring(Core.getMyDocumentFolder() ..
        getFileSeparator() ..
        "Saves" ..
        getFileSeparator() ..
        getWorld():getGameMode() .. getFileSeparator() .. getWorld():getWorld() .. getFileSeparator()
    );
    return stringPath;
end

function Data.init( inner_function ) -- [testing]
    Events.OnInitGlobalModData.Add( inner_function )
end

-- 
-- ====================================================================
--

return Data
