
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================
-- File [ context_menu.lua ] : Context Menu Facilities

-- Inventory [ .../context_menu.lua ]
-- 1. ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, callback )
-- 2. ContextMenu.inventoryObjectRegister( inner_function ) o inner_function(context,item,isoplayer,items)
-- 3. ContextMenu.worldObjectRegister( inner_function ) o inner_function(context,object,isoplayer,worldobjects)
-- 4. ContextMenu.addOption(context, name, target_object, callback)
-- 5. ContextMenu.createContextMenuStructureFromStringTable(string_table, callback_dictionary, parent_context, target_object)
-- --------------------------- LIB | VANILLA --------------------------
-- 1. CONTEXT:addOption(name, target, callback)
-- 2. CONTEXT:addSubMenu(submenu_displayed_option, submenu)
-- local PARENT_DIR = PLS DEFINE ME !!!
-- local ContextMenu = require(PARENT_DIR.."context_menu")

local ContextMenu = {}

--
-- ====================================================================
-- THEORY

-- This library is designed to construct context menu interface with minimal code.
-- Is strongly suggested to use anonymous functions whenever you find inner_function variables.
-- For example:
--[[ Instead of writing
    
function my_register(...)
    -- something
end

ContextMenu.inventoryObjectRegister(my_register)

--]]
--[[ Write this

ContextMenu.inventoryObjectRegister( function() 
    -- something
end )

--]]

-- Function Description:
-- 1. worldObjectRegister ; register the inner_function on context menu event for world objects
-- 2. inventoryObjectRegister ; ...
-- 3. createContextMenuStructureFromStringTable ; create the context menu structure based on array of strings.
-- 4. addOption ; add option to context menu
-- 5. createSubmenu ; create a submenu for a parent context menu

--
-- ====================================================================
--

-- ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, [ callback ] )
function ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, callback ) -- [ok]
    if not callback then callback = nil end
    local SUBMENU = ISContextMenu:getNew(parent_context_menu)
    local SUBMENU_DISPLAYED_OPTION = parent_context_menu:addOption(submenu_name, target_object, callback )
    parent_context_menu:addSubMenu(SUBMENU_DISPLAYED_OPTION, SUBMENU)
    return SUBMENU
end

-- ContextMenu.inventoryObjectRegister o inner_function(context,item,isoplayer,items)
-- 1. inner_function returning true means that the item is found and the context filled.
function ContextMenu.inventoryObjectRegister( inner_function ) -- [ok]
    if not inner_function then return nil end
    --
    local function Filler(player_num, context, items)
        local isoplayer = getSpecificPlayer(player_num)
        if not isoplayer then return nil end
        if not items then return nil end -- is this necessary?
        if not context then return nil end -- is this necessary?
        -- 
        for index,item in ipairs(items) do 
            if inner_function(context,item,isoplayer,items)==true then break end
        end
    end
    --
    Events.OnFillInventoryObjectContextMenu.Add(Filler)
end

-- ContextMenu.worldObjectRegister o inner_function(context,object,isoplayer,worldobjects)
function ContextMenu.worldObjectRegister( inner_function ) -- [ok]
    if not inner_function then return nil end
    --
    local function Filler(player_num, context, worldobjects)
        local isoplayer = getSpecificPlayer(player_num)
        if not isoplayer then return nil end
        if not worldobjects then return nil end -- is this necessary?
        if not context then return nil end -- is this necessary?
        -- 
        for index,object in ipairs(worldobjects) do
            if inner_function(context,object,isoplayer,worldobjects)==true then break end
        end
    end
    --
    Events.OnFillWorldObjectContextMenu.Add(Filler)
end

-- Obsessive-Compulsive-Disorder Function
function ContextMenu.addOption(context, name, target_object, callback) -- [ok]
    return context:addOption(name, target_object, callback)
end

-- 
function ContextMenu.createContextMenuStructureFromStringTable(string_table, callback_dictionary, parent_context, target_object) -- [testing]
    for _,value in ipairs(string_table) do 
        if type(value)=="string" then 
            ContextMenu.addOption(parent_context, value, target_object, callback_dictionary[value] )
        elseif type(value)=="table" then
            local SUBMENU = ContextMenu.createSubmenu(parent_context, value.name, target_object, nil) -- [ok]
            ContextMenu.createContextMenuStructureFromStringTable(value, callback_dictionary, SUBMENU, target_object)
        end
    end
    return parent_context
end

--
-- ====================================================================
-- EXAMPLES 
--> Copy the example content on separate mod file.

--[[ Example 1 ; using the functions worldObjectRegister, createSubmenu
local ContextMenu = require(ROOT_DIR.."context_menu")

ContextMenu.worldObjectRegister( function(context, object, isoplayer) 
    if not object then return nil end
    -- 
    context:addOption( "My Option", object, function() 
        isoplayer:Say("Hello Option")
    end )
    --
    local SUBMENU = ContextMenu.createSubmenu(context, "My Submenu", object, nil )
    SUBMENU:addOption("option 1", object, function() 
        isoplayer:Say("Option 1")
    end)
    SUBMENU:addOption("option 2", object, function() 
        isoplayer:Say("Option 2")
    end)
    return true
end )
--]]

--[[ Example 2 ; Using the function createContextMenuStructureFromStringTable
local ContextMenu = require(ROOT_DIR.."context_menu")

ContextMenu.worldObjectRegister( function(context, object, isoplayer) 
    local callback_dictionary = {}
    callback_dictionary["Option 1"] = function() isoplayer:Say("Option 1") end
    callback_dictionary["Option 2"] = function() isoplayer:Say("Option 2") end
    callback_dictionary["Option 3"] = function() isoplayer:Say("Option 3") end
    callback_dictionary["Suboption 1"] = function() isoplayer:Say("Suboption 1") end
    callback_dictionary["Suboption 2"] = function() isoplayer:Say("Suboption 2") end
    ContextMenu.createContextMenuStructureFromStringTable( {
        "Option 1",
        "Option 2",
        { name = "Submenu 1", 
            "Suboption 1",
            "Suboption 2"
        },
        "Option 3"
    }, callback_dictionary, context, object)
    return true -- prevent repetition for other objects.
end )
--]]

--
-- ====================================================================
--

return ContextMenu
