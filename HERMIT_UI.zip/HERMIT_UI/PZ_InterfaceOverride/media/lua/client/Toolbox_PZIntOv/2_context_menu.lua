
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================
-- File [ 2_context_menu.lua ] : Right-Click Interface

-- Inventory [ .../2_context_menu.lua ]
-- ---------------------- VARIABLES | FUNCTIONS -----------------------
-- 1. ContextMenu.addOption(context, name, target_object, callback)
-- 2. ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, callback )
-- 3. ContextMenu.createContextMenuStructureFromStringTable(string_table, callback_dictionary, parent_context, target_object)
-- 4. ContextMenu.IExposedInventory( inner_function, [ item_full_type ] ) o (Interface)
-- ... Exposed Inventory are Hotbar, Primary and Secondary icon and Side Icons of Each Loot and Inventory Panel
-- ... Not work with items inside the list of loot and inventory panel
-- 5. ContextMenu.IWorld( inner_function, [ texture_name_substring ] ) o (Interface)
-- 6. ContextMenu.setOptionCallback(option, callback)
-- 7. ContextMenu.getOptionName(option)
-- 8. ContextMenu.getOptionFromName(context, name)
-- 9. ContextMenu.FOption(context, inner_function) o (name,option, SetCallback, option_id)
-- 10. ContextMenu.getFontMedium()
-- 11. ContextMenu.getFontSmall()
-- 12. ContextMenu.getFontLarge()
-- 13. ContextMenu.setFont(context, font)
-- 14. ContextMenu.ContextPrerender(inner_function) o (Color,Border,Font,ISContextMenu_self)
-- --------------------------- LIB | VANILLA --------------------------
-- local PARENT_DIR = 
-- local Data = require(PARENT_DIR.."2_context_menu")

-- Inventory [ Prototype : ProtoInterface ]
-- 1. ProtoInterface.topmost_context
-- 2. ProtoInterface.target
-- 3. ProtoInterface.list
-- 4. ProtoInterface.index
-- 5. ProtoInterface.isoplayer
-- --------------------- ATTRIBUTES | METHODS -------------------------
-- 1. ProtoInterface:SetAttributes(index,object,objects) 
-- 2. ProtoInterface:Option(name,callback, [ parent_context ])
-- 3. ProtoInterface:Submenu(name,[ parent_context, callback ]) 
-- 4. ProtoInterface:Structure(string_table, callback_dictionary, [ parent_context ]) 
-- 5. ProtoInterface:PrintNames()

local ContextMenu = {}

--
-- ====================================================================
-- Scrapped

local function singlePrototype(inner_function,prototype,function_name) -- [testing]
    if not prototype then return nil end
    if not prototype[function_name] then return nil end
    local old = prototype[function_name]
    prototype[function_name] = function(...)
        return inner_function(old,...)
    end
end

local function multiplePrototypes(inner_function,function_name,prototype_array_table) -- [ok]
    for i,v in ipairs(prototype_array_table) do 
        singlePrototype(inner_function, v,function_name)
    end
end

--
-- ====================================================================
-- Wrapping Events On Fill Inventory and World Context Menu

-- Obsessive-Compulsive-Disorder Function
function ContextMenu.addOption(context, name, target_object, callback) -- [ok]
    return context:addOption(name, target_object, callback)
end

-- ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, [ callback ] )
function ContextMenu.createSubmenu(parent_context_menu, submenu_name, target_object, callback ) -- [ok]
    if not callback then callback = nil end
    local SUBMENU = ISContextMenu:getNew(parent_context_menu)
    local SUBMENU_DISPLAYED_OPTION = parent_context_menu:addOption(submenu_name, target_object, callback )
    parent_context_menu:addSubMenu(SUBMENU_DISPLAYED_OPTION, SUBMENU)
    return SUBMENU
end

function ContextMenu.createContextMenuStructureFromStringTable(string_table, callback_dictionary, parent_context, target_object) -- [ok]
    for _,value in ipairs(string_table) do 
        if type(value)=="string" then 
            ContextMenu.addOption(parent_context, value, target_object, callback_dictionary[value] )
        elseif type(value)=="table" then
            local SUBMENU = ContextMenu.createSubmenu(parent_context, value.name, target_object, nil) -- [ok]
            ContextMenu.createContextMenuStructureFromStringTable(value, callback_dictionary, SUBMENU, target_object)
        end
    end
    return parent_context
end

local ProtoInterface = {}
-- Prototype: ProtoInterface || Constructor
function ProtoInterface:new(context, isoplayer)
    local obj = {}
    -- Setting Attributes
    obj.topmost_context = nil
    obj.target = nil
    obj.list = nil
    obj.index = nil
    obj.isoplayer = nil
    -- update constructor arguments
    if context~=nil then 
        if not isoplayer then isoplayer = getSpecificPlayer(0) end
        obj.topmost_context = context 
        obj.isoplayer = isoplayer
    end
    -- 
    setmetatable(obj, self)
    self.__index = self
    return obj
end
-- Prototype: ProtoInterface || Methods
function ProtoInterface:SetAttributes(index,object,objects) -- [ok]
    self.index = index
    self.target = object
    self.list = objects
end
function ProtoInterface:Option(name,callback,parent_context) -- [ok]
    if not parent_context then parent_context = self.topmost_context end
    return parent_context:addOption(name, self.target, callback)
end
function ProtoInterface:Submenu(name,parent_context,callback) -- [ok]
    if not parent_context then parent_context = self.topmost_context end
    return ContextMenu.createSubmenu(parent_context, name, self.target, callback)
end
function ProtoInterface:Structure(string_table, callback_dictionary, parent_context) -- [ok]
    if not parent_context then parent_context = self.topmost_context end
    return ContextMenu.createContextMenuStructureFromStringTable(string_table, callback_dictionary, parent_context, self.target)
end
function ProtoInterface:PrintNames() -- [testing]
    local info_str = ""
    if self.target.getName then 
        info_str = info_str.."getName() = "..tostring(self.target:getName()).."\n"
    end
    if self.target.getObjectName then 
        info_str = info_str.."getObjectName() = "..tostring(self.target:getObjectName()).."\n"
    end
    if self.target.getScriptName then 
        info_str = info_str.."getScriptName() = "..tostring(self.target:getScriptName()).."\n"
    end
    if self.target.getFullType then 
        info_str = info_str.."getFullType() = "..tostring(self.target:getFullType()).."\n"
    end
    if self.target.getType then 
        info_str = info_str.."getType() = "..tostring(self.target:getType()).."\n"
    end
    if self.target.getTextureName then 
        info_str = info_str.."getTextureName() = "..tostring(self.target:getTextureName()).."\n"
    end
    if self.target.getTile then 
        info_str = info_str.."getTile() = "..tostring(self.target:getTile()).."\n"
    end
    self.isoplayer:Say( info_str )
end

-- ContextMenu.IExposedInventory( inner_function, [ item_full_type ] ) o (Interface)
-- ... if the inner_function return true the internal loop breaks on first satisfied item type
function ContextMenu.IExposedInventory( inner_function, item_full_type ) -- [testing]
    -- Filler
    local function Filler(player_num, context, items)
        local Interface = ProtoInterface:new(context, getSpecificPlayer(player_num))
        --
        for index,item in ipairs(items) do 
            -- Update Variables for Interface
            Interface:SetAttributes(index,item,items)
            --
            if item_full_type~=nil then 
                if item_full_type==item:getFullType() then 
                    if inner_function(Interface)==true then break end
                end
            else 
                if inner_function(Interface)==true then break end
            end
        end
    end
    -- Event
    Events.OnFillInventoryObjectContextMenu.Add(Filler)
end

-- ContextMenu.IWorld( inner_function, [ texture_name_substring ] ) o (Interface)
-- ... if the inner_function return true the internal loop breaks on first satisfied object 
function ContextMenu.IWorld( inner_function, texture_name_substring ) -- [ok]
    -- Filler
    local function Filler(player_num, context, worldobjects)
        -- Interface
        local Interface = ProtoInterface:new(context, getSpecificPlayer(player_num))
        -- 
        for index,object in ipairs(worldobjects) do
            -- Update Variables for Interface
            Interface:SetAttributes(index,object,worldobjects)
            --           
            if texture_name_substring~=nil and texture_name_substring~="" then 
                if string.find( self.target:getTextureName(),texture_name_substring ) then 
                    if inner_function(Interface)==true then break end
                end
            else 
                if inner_function(Interface)==true then break end
            end
        end
    end
    -- Event
    Events.OnFillWorldObjectContextMenu.Add(Filler)
end

--[[ Example ; IWorld, Option, Submenu
ContextMenu.IWorld( function(Interface) 
    local SM = Interface:Submenu("This is my menu")
    Interface:Option("my option 1", function() 
        Interface.isoplayer:Say("This is my option 1")
    end, SM )
    Interface:Option("my option 2", function() 
        Interface.isoplayer:Say("This is my option 2")
    end, SM )
    return true
end )
--]]

--[[ Example ; IWorld, Structure
ContextMenu.IWorld( function(Interface) 
    local callback_dictionary = {}
    callback_dictionary["Option 1"] = function() Interface.isoplayer:Say("Option 1") end
    callback_dictionary["Option 2"] = function() Interface.isoplayer:Say("Option 2") end
    callback_dictionary["Option 3"] = function() Interface.isoplayer:Say("Option 3") end
    Interface:Structure( {
        { name = "My Submenu", 
            "Option 1",
            "Option 2"
        },
        "Option 3"
    }, callback_dictionary )
    return true
end )
--]]

--[[ Example ; IWorld, Structure, PrintNames
ContextMenu.IWorld( function(Interface) 
    local callback_dictionary = {}
    callback_dictionary["Print Info"] = function() Interface:PrintNames() end
    Interface:Structure( {
        { name = Interface.target:getTextureName(),
            "Print Info"
        }
    }, callback_dictionary )
end )
--]]

--
-- ====================================================================
-- Override Inventory Pane Context Menu

function ContextMenu.COverrideInventoryPane(inner_function, function_name) -- [testing]
    local Structure = ContextMenu.createContextMenuStructureFromStringTable
    local Option = ContextMenu.addOption
    local Submenu = ContextMenu.createSubmenu
    singlePrototype( function(old,...) 
        old(...)
        inner_function(Structure, Option, Submenu,...)
    end, ISInventoryPaneContextMenu,function_name)
end

--[[ Example ; COverrideInventoryPane, doWearClothingMenu
ContextMenu.COverrideInventoryPane( function(Structure, Option, Submenu, player, clothing, items, context) 
    Option( context,"my wear option",nil,function() 
        getSpecificPlayer(0):Say("This is My Option")
    end )
end, "doWearClothingMenu")
--]]

--
-- ====================================================================
-- Utilities

function ContextMenu.setOptionCallback(option, callback) -- [testing]
    option.onSelect = callback
end

function ContextMenu.getOptionName(option) -- [testing]
    return option.name
end

function ContextMenu.getOptionFromName(context, name) -- [testing]
    context:getOptionFromName(name)
end

-- ContextMenu.FOption(context, inner_function) o (name,option, SetCallback, option_id)
function ContextMenu.FOption(context, inner_function) -- [ok]
    for index, value in ipairs(context.options) do
        --
        local function SetCallback(callback)
            ContextMenu.setOptionCallback(value, callback)
        end
        --
        local inner_function_ret = inner_function(value.name, value, SetCallback,index)
        if inner_function_ret == nil then 
        else 
            if inner_function_ret == true then
                break 
            else
                return inner_function_ret 
            end
        end
    end
end

--[[ Example
ContextMenu.COverrideInventoryPane( function(Structure, Option, Submenu, player, clothing, items, context) 
    local print_str = ""
    ContextMenu.FOption(context, function(name,option) 
        print_str = print_str..name.."\n"
        return nil
    end )
    getSpecificPlayer(player):Say(print_str)
end, "doWearClothingMenu")
--]]

function ContextMenu.getFontMedium() -- [testing]
    return UIFont.Medium
end

function ContextMenu.getFontSmall() -- [testing]
    return UIFont.Small
end

function ContextMenu.getFontLarge() -- [testing]
    return UIFont.Large
end

function ContextMenu.setFont(font, context) -- [testing]
    if font == "medium" or font == "med" then 
        font = UIFont.Medium
    elseif font == "small" then
        font = UIFont.Small
    elseif font == "large" then 
        font = UIFont.Large
    end
    context.font = font
    context.fontHgt = getTextManager():getFontFromEnum(font):getLineHeight()
    context.itemHgt = context.fontHgt+context.padY*2
    context:calcHeight()
end

--
-- ====================================================================
-- 

-- ContextMenu.ContextPrerender(inner_function) o (Color,Border,Font,ISContextMenu_self)
function ContextMenu.ContextPrerender(inner_function) -- [ok]
    -- Functions
    local function Set(obj,index,value)
        if not value or value==nil then return nil end
        obj[index] = value
    end
    -- Override
    singlePrototype( function(old,self) 
        old(self)
        local function Color(r,g,b,a)
            Set(self.backgroundColor, "r", r)
            Set(self.backgroundColor, "g", g)
            Set(self.backgroundColor, "b", b)
            Set(self.backgroundColor, "a", a)
        end
        local function Border(r,g,b,a) 
            Set(self.borderColor, "r", r)
            Set(self.borderColor, "g", g)
            Set(self.borderColor, "b", b)
            Set(self.borderColor, "a", a)
        end
        local function Font(font)
            ContextMenu.setFont(font, self)
        end
        inner_function(Color,Border,Font,self)
    end, ISContextMenu, "prerender" )
end

--[[ Example ; ContextPrerender
ContextMenu.ContextPrerender( function(Color,Border,Font) 
    Color(nil,nil,nil,0.4)
    Border(0,1,1,1)
    Font("small")
end ) 
--]]

--
-- ====================================================================
--

return ContextMenu






























