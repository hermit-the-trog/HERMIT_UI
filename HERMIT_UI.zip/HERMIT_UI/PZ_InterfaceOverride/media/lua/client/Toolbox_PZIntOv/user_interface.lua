
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================
-- File [ user_interface.lua ] : Graphical User Interface Utilities

-- Inventory [ .../user_interface.lua ]
-- 1. UserInterface.texture_path ; "media/textures/"
-- ---------------- Variables | Functions --------------------
-- 1. UserInterface.inGame(inner_function) o (screen_width, screen_height, core)
-- 2. UserInterface.floatingButton( name, texture_path, [ texture_object, x,y, width, height ])
-- 3. UserInterface.window(name,[ x,y,width,height ])
-- 4. UserInterface.childButton(parent, name, text, callback, [ x, y, width, height ])
-- 5. UserInterface.childMultilineEntry(parent, name, [ x, y, width, height ])
-- 6. UserInterface.childSlider(parent, name, callback , [ x, y, width, height ] ) 
-- 7. UserInterface.foreachUserInterface o (ui,ui_object_name, ui_index, uis)
-- 8. UserInterface.foreachHudButton(inner_function) o (ui)
-- 9. UserInterface.setImage(texture_path, [ texture_object ])
-- 10. UserInterface.setOnClick(interface_object, callback)
-- 11. UserInterface.setOnClickHotbar(inner_function) o (clickedSlotIndex, item)
-- 12. UserInterface.setOnMap( interface_object )
-- 13. UserInterface.getScreenXYfromWorldXYZ(x,y, [ z ])
-- 14. UserInterface.getItemTexture(item) ; same as item:getTex()
-- --------------------------- LIB | VANILLA --------------------------
-- 1. UI:setVisible(boolean)
-- 2. UI:setY() ; UI:getY()
--  . UI:setEditable(boolean)
--  . getTexture(file_path)
-- local PARENT_DIR = DEFINE ME PLS !!!
-- local UserInterface = require(PARENT_DIR.."user_interface")

local UserInterface = {}
UserInterface.texture_path = "media/textures/"

--
-- ====================================================================
-- Requires

require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISLayoutManager"
require "RadioCom/ISUIRadio/ISSliderPanel"

--
-- ====================================================================
--

-- Local Inventory:
-- ISVehicleSeatUI:new() || ISPanelJoypad:new() 
-- ISHealthBodyPartListBox:new() || ISScrollingListBox:new () || ISPanelJoypad:new() 
-- ISHotbar:new(character)
-- ISPanelJoypad:new(x, y, width, height)
-- ISLightbarUI:new() || ISPanelJoypad:new() 
-- ISHealthBodyPartListBox:new(x, y, width, height)
-- ISMediaInfo:new(x, y, width, height, playerNum, text)
-- ISRichTextPanel:new (x, y, width, height)
-- ISUIWriteJournal:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- ISVehicleACUI:new() || ISPanelJoypad:new() 
-- ISMakeUpUI:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- ISMakeUpUI:new(x, y, item, character)
-- ISRichTextPanel:new() || ISPanel:new()
-- ISTextBox:new() || ISPanelJoypad:new() 
-- ISPanel:new(x, y, width, height);
-- PZNS_NPCSurvivor:newSurvivor( survivorID, survivorName, npcIsoPlayerObject)
-- ISCollapsableWindowJoypad:new (x, y, width, height)
-- ISLiteratureUI:new(x, y, width, height, character, owner)
-- ISHealthPanel:new (player, x, y, width, height)
-- ISTextBoxMap:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- ISVehicleSeatUI:new(x, y, character)
-- ISVehicleACUI:new(x, y, character)
-- ISLiteratureUI:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- ISHealthPanel:new() || ISPanelJoypad:new()
-- ISMediaInfo:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- WorldMapOptions:new() || ISCollapsableWindowJoypad:new () || ISPanelJoypad:new() 
-- ISScrollingListBox:new (x, y, width, height)
-- ISTextBox:new(x, y, width, height, text, defaultEntryText, target, onclick, player, param1, param2, param3, param4)
-- ISLightbarUI:new(x, y, width, height, playerObj)

-- UserInterface.floatingButton( name, texture_path, [ texture_object, x,y, width, height ])
function UserInterface.floatingButton(name,texture_path, texture_object,x,y,width,height ) -- [ok]
    -- optional arguments
    if not x then x = getCore():getScreenWidth() - 100 end
    if not y then y = getCore():getScreenHeight() - 50 end
    if not width then width = 25 end
    if not height then height = 25 end
    local Texture = nil do 
        if texture_object then 
            Texture = texture_object
        else 
            Texture = getTexture(texture_path)
        end
    end
    -- object construction
    local BUTTON_PROTOTYPE = ISButton:derive(name)
    local BUTTON = BUTTON_PROTOTYPE:new(x, y, width, height, "", nil, nil)
    BUTTON:setImage(Texture)
    BUTTON:setVisible(true)
    BUTTON:setEnable(true)
    BUTTON:addToUIManager()
    return BUTTON
end

function UserInterface.setOnClick(interface_object, callback) -- [ok]
    interface_object.onclick = callback
end

-- UserInterface.inGame(inner_function) o (screen_width, screen_height, CORE)
function UserInterface.inGame(inner_function) -- [ok]
    local CORE = getCore()
    local screen_width = CORE:getScreenWidth()
    local screen_height = CORE:getScreenHeight()
    Events.OnGameStart.Add( function()
        inner_function(screen_width, screen_height, CORE)
    end )
end

-- UserInterface.setImage(texture_path, texture_object)
function UserInterface.setImage(interface_object, texture_path, texture_object) -- [ok]
    if texture_object then 
        interface_object:setImage(texture_object)
    elseif texture_path then 
        interface_object:setImage( getTexture( texture_path ) )
    end
end

-- Obsessive–Compulsive-Disorder Part
function UserInterface.getItemTexture(item) -- [ok]
    return item:getTex()
end

-- UserInterface.foreachUserInterface o (ui,ui_object_name, ui_index, uis)
function UserInterface.foreachUserInterface(inner_function) -- [ok]
    local uis = UIManager.getUI()
    if uis:size()==0 then return nil end
    for i=0, uis:size() - 1 do
        local current_ui = uis:get(i)
        local current_ui_object_name = tostring(current_ui)
        local current_ui_index = i
        local ret_in = inner_function(current_ui,current_ui_object_name, current_ui_index, uis)
        if ret_in == nil then 
        else 
            if ret_in == true then 
                break
            else 
                return ret_in
            end
        end
    end
end

-- UserInterface.setOnClickHotbar(inner_function) o (clickedSlotIndex, item)
function UserInterface.setOnClickHotbar(inner_function) -- [testing]
    function ISHotbar:onMouseUp(x, y)
        local counta = 1;
        local clickedSlot = self:getSlotIndexAt(x, y);
        if ISMouseDrag.dragging then
            local slot = self.availableSlot[clickedSlot];
            local dragging = ISInventoryPane.getActualItems(ISMouseDrag.dragging);
            for i,v in ipairs(dragging) do
                if (v ~= self.attachedItems[clickedSlot]) and self:canBeAttached(slot, v) then
                    local weapon = v;
                    self:attachItem(weapon, slot.def.attachments[weapon:getAttachmentType()], clickedSlot, slot.def, true);
                    break;
                end
            end
        else 
            inner_function(clickedSlot, self.attachedItems[clickedSlot])
        end
    end
end

function UserInterface.setOnMap( interface_object ) -- [testing]
    local old_update = interface_object.update
    interface_object:setVisible(false)
    interface_object:setAlwaysOnTop(true)
    function interface_object:update() 
        old_update(self)
        if ISWorldMap_instance then 
            if ISWorldMap_instance:isVisible() then
                self:setVisible(true)
            else 
                self:setVisible(false)
            end
        end
    end
end

-- UserInterface.getScreenXYfromWorldXYZ(x,y, [ z ])
function UserInterface.getScreenXYfromWorldXYZ(x,y,z) -- [testing]
    if not z then z = 0 end
    local X = IsoUtils.XToScreen(x,y,z,0) - IsoCamera.getOffX()
    local Y = IsoUtils.YToScreen(x,y,z,0) - IsoCamera.getOffY()
    X = X / getCore():getZoom(0)
    Y = Y / getCore():getZoom(0)
    return X,Y
end

-- Logic [ Main Screen Menu ]
--> MainScreen:instantiate() || $ self.exitOption || { ISLabel:new }
--> self.bottomPanel:addChild( self.exitOption ) 

function UserInterface.foreachHudButton(inner_function) -- [ok]
    local UI = nil 
    local ret = nil
    UI = ISEquippedItem.instance.healthBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.invBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.craftingBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.mapBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.searchBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.movableBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.debugBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.clientBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
    --
    UI = ISEquippedItem.instance.adminBtn
    ret = inner_function(UI)
    if ret == nil then 
    else 
        if ret == true then 
            return 
        else
            return ret
        end
    end
end

-- UserInterface.window(name,[ x,y,width,height ])
function UserInterface.window(name,x,y,width,height) -- [ok]
    if not x then x = getCore():getScreenWidth()/2 end
    if not y then y = getCore():getScreenHeight()/2 end
    if not width then width = 200 end
    if not height then height = 200 end
    local PANEL = ISCollapsableWindow:new(x,y,width ,height)
    PANEL:setVisible(false)
    PANEL:addToUIManager()
    return PANEL
end

local FONT_HGT_SMALL = getTextManager():getFontHeight(UIFont.Small)
-- UserInterface.childButton(parent, name, text, callback, [ x, y, width, height ])
function UserInterface.childButton(parent, name, text, callback, x, y, width, height) -- [ok]
    --
    local bottom = parent:getHeight()
    local btnWid = 60
    local btnHgt = math.max(FONT_HGT_SMALL + 3 * 2, 25)
    --
    if not x then x = 10 end
    if not y then y = bottom - btnHgt - 10 end
    if not width then width = btnWid end
    if not height then height = btnHgt end
    --
    parent[name] = ISButton:new(x, y, width, height, text, parent, callback)
    parent[name].internal = name;
    parent[name]:initialise();
    parent[name]:instantiate();
    parent[name].borderColor = {r=1, g=1, b=1, a=0.1};
    parent:addChild(parent[name])
    return parent[name]
end

-- UserInterface.childMultilineEntry(parent, name, [ x, y, width, height ])
function UserInterface.childMultilineEntry(parent, name, text,x, y, width, height) -- [ok]
    -- optional arguments
    if not x then x = 5 end
    if not y then y = 25 end
    if not width then width = parent:getWidth()*0.8 end
    if not height then height = parent:getHeight()*0.6 end
    if not text then text = "" end
    --
    parent[name] = ISTextEntryBox:new(text,x,y,width,height)
    parent[name]:initialise()
    parent[name]:instantiate()
    parent[name]:setMultipleLine(true)
    parent[name].javaObject:setMaxLines(10)
    parent[name].javaObject:setMaxTextLength(500)
    parent:addChild( parent[name] )
    parent[name]:setEditable(true) 
    return parent[name]
end

-- UserInterface.childSlider(parent, name, callback , [ x, y, width, height, default_value ] ) 
function UserInterface.childSlider(parent, name, callback, x, y, width, height, default_value) -- [ok]
    if not x then x = 5 end
    if not y then y = 25 end
    if not width then width = parent:getWidth()*0.95 end
    if not height then height = 20 end
    if not default_value then default_value = 0.0 end
    parent[name] = ISSliderPanel:new( x, y, width, height, parent, nil )
    parent[name]:initialise()
    parent[name]:instantiate()
    parent[name].valueLabel = true
    parent[name]:setValues(0.0, 100.0, 0.1, 1.0)
	parent[name]:setCurrentValue(default_value, true)
    local old = parent[name].doOnValueChange
    parent[name].doOnValueChange = function( self, _newValue )
        old(self, _newValue)
        return callback(parent, name)
    end
    parent:addChild(parent[name])
    return parent[name]
end

--
-- ====================================================================
-- Examples
-- 1. Create a Separate File and Follow the Syntax for Importing Functions

--[[ Example : UserInterface.floatingButton

local UserInterface = require(ROOT_DIR.."user_interface")

UserInterface.inGame( function() 
    local PLAYER = getSpecificPlayer(0)
    local primary = PLAYER:getPrimaryHandItem()
    local texture = UserInterface.getItemTexture(primary)
    MY_TOGGLE_BUTTON = UserInterface.floatingButton("My Button", nil, texture)
    UserInterface.setOnClick( MY_TOGGLE_BUTTON, function() 
        PLAYER:Say("this is my weapon")
        UserInterface.setImage(MY_TOGGLE_BUTTON,nil,texture)
    end )
end )

--]]

--[[ Example : UserInterface.floatingCollapsableWindow
-- user_interface
local UserInterface = require(PARENT_DIR.."user_interface")
local MOD_LAB_PANEL = nil
UserInterface.inGame( function(screen_width,screen_height,core)
    MOD_LAB_PANEL = UserInterface.floatingCollapsableWindow("My Panel")
    MOD_LAB_PANEL:setVisible(true)
    -- UserInterface.childButton(parent, name, text, callback, [ x, y, width, height ])
    local okay = UserInterface.childButton(MOD_LAB_PANEL, "okay_button","ok", function() 
        local isoplayer = getSpecificPlayer(0)
        isoplayer:Say("MY OKAY BUTTON")
    end )
    UserInterface.childButton(MOD_LAB_PANEL, "cancel_button","cancel", function() 
        local isoplayer = getSpecificPlayer(0)
        isoplayer:Say("MY CANCEL BUTTON")
    end, okay:getX() + okay:getWidth()+10, okay:getY() )
end ) 
--]]

--[[ Example : UserInterface.childSlider
local UserInterface = require(PARENT_DIR.."user_interface")
local MOD_LAB_PANEL = nil
UserInterface.inGame( function(screen_width,screen_height,core)
    MOD_LAB_PANEL = UserInterface.window("My Panel")
    MOD_LAB_PANEL:setVisible(true)
    local SLIDER_1 = UserInterface.childSlider( MOD_LAB_PANEL, "My Slider 1", function(parent, name)
        local isoplayer = getSpecificPlayer(0)
        isoplayer:Say( "My Slider 1 Value: "..tostring( parent[name]:getCurrentValue() ) )
    end ) 
    local SLIDER_2 = UserInterface.childSlider( MOD_LAB_PANEL, "My Slider 2", function(parent, name)
        local isoplayer = getSpecificPlayer(0)
        isoplayer:Say( "My Slider 2 Value: "..tostring( parent[name]:getCurrentValue() ) )
    end, nil, SLIDER_1:getY()+SLIDER_1:getHeight()+10 ) 
end ) 
--]]

return UserInterface











