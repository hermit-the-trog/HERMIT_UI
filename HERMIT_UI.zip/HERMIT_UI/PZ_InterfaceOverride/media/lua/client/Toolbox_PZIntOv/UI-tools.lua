local UserInterface = {}
UserInterface.texture_path = "media/textures/"

-- Requires

require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISLayoutManager"
require "RadioCom/ISUIRadio/ISSliderPanel"

function UserInterface.floatingButton(name, texture_path, texture_object, x, y, width, height)
    if not x then x = getCore():getScreenWidth() - 100 end
    if not y then y = getCore():getScreenHeight() - 50 end
    if not width then width = 25 end
    if not height then height = 25 end
    local Texture = texture_object or getTexture(texture_path)
    local BUTTON_PROTOTYPE = ISButton:derive(name)
    local BUTTON = BUTTON_PROTOTYPE:new(x, y, width, height, "", nil, nil)
    BUTTON:setImage(Texture)
    BUTTON:setVisible(true)
    BUTTON:setEnable(true)
    BUTTON:addToUIManager()
    return BUTTON
end

function UserInterface.setOnClick(interface_object, callback)
    interface_object.onclick = callback
end
function UserInterface.inGame(inner_function)
    local CORE = getCore()
    local screen_width = CORE:getScreenWidth()
    local screen_height = CORE:getScreenHeight()
    Events.OnGameStart.Add(function()
        inner_function(screen_width, screen_height, CORE)
    end)
end

function UserInterface.setImage(interface_object, texture_path, texture_object)
    if texture_object then
        interface_object:setImage(texture_object)
    elseif texture_path then
        interface_object:setImage(getTexture(texture_path))
    end
end

function UserInterface.getItemTexture(item)
    return item:getTex()
end

function UserInterface.foreachUserInterface(inner_function)
    local uis = UIManager.getUI()
    if uis:size() == 0 then return nil end
    for i = 0, uis:size() - 1 do
        local current_ui = uis:get(i)
        local ret_in = inner_function(current_ui, tostring(current_ui), i, uis)
        if ret_in ~= nil then 
            if ret_in == true then 
                break 
            else 
                return ret_in
            end
        end
    end
end
function UserInterface.setOnClickHotbar(inner_function)
    function ISHotbar:onMouseUp(x, y)
        local counta = 1;
        local clickedSlot = self:getSlotIndexAt(x, y);
        if ISMouseDrag.dragging then
            local slot = self.availableSlot[clickedSlot];
            local dragging = ISInventoryPane.getActualItems(ISMouseDrag.dragging);
            for i, v in ipairs(dragging) do
                if (v ~= self.attachedItems[clickedSlot]) and self:canBeAttached(slot, v) then
                    local weapon = v;
                    self:attachItem(weapon, slot.def.attachments[weapon:getAttachmentType()], clickedSlot, slot.def, true);
                    break;
                end
            end
        else
            inner_function(clickedSlot, self.attachedItems[clickedSlot])
        end
    end
end

function UserInterface.setOnMap(interface_object)
    local old_update = interface_object.update
    interface_object:setVisible(false)
    interface_object:setAlwaysOnTop(true)
    function interface_object:update()
        old_update(self)
        if ISWorldMap_instance then
            if ISWorldMap_instance:isVisible() then
                self:setVisible(true)
            else
                self:setVisible(false)
            end
        end
    end
end
function UserInterface.getScreenXYfromWorldXYZ(x, y, z)
    if not z then z = 0 end
    local X = IsoUtils.XToScreen(x, y, z, 0) - IsoCamera.getOffX()
    local Y = IsoUtils.YToScreen(x, y, z, 0) - IsoCamera.getOffY()
    X = X / getCore():getZoom(0)
    Y = Y / getCore():getZoom(0)
    return X, Y
end

function UserInterface.foreachHudButton(inner_function)
    local UI = nil
    local ret = nil
    UI = ISEquippedItem.instance.healthBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.invBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.craftingBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.mapBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.searchBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.movableBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.debugBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.clientBtn
    ret = inner_function(UI)
    if ret then return ret end
    UI = ISEquippedItem.instance.adminBtn
    ret = inner_function(UI)
    if ret then return ret end
end
function UserInterface.window(name, x, y, width, height)
    if not x then x = getCore():getScreenWidth() / 2 end
    if not y then y = getCore():getScreenHeight() / 2 end
    if not width then width = 200 end
    if not height then height = 200 end
    local PANEL = ISCollapsableWindow:new(x, y, width, height)
    PANEL:setVisible(false)
    PANEL:addToUIManager()
    return PANEL
end

local FONT_HGT_SMALL = getTextManager():getFontHeight(UIFont.Small)

function UserInterface.childButton(parent, name, text, callback, x, y, width, height)
    local bottom = parent:getHeight()
    local btnWid = 60
    local btnHgt = math.max(FONT_HGT_SMALL + 3 * 2, 25)
    if not x then x = 10 end
    if not y then y = bottom - btnHgt - 10 end
    if not width then width = btnWid end
    if not height then height = btnHgt end
    parent[name] = ISButton:new(x, y, width, height, text, parent, callback)
    parent[name].internal = name
    parent[name]:initialise()
    parent[name]:instantiate()
    parent[name].borderColor = {r = 1, g = 1, b = 1, a = 0.1}
    parent:addChild(parent[name])
    return parent[name]
end

function UserInterface.childMultilineEntry(parent, name, text, x, y, width, height)
    if not x then x = 5 end
    if not y then y = 25 end
    if not width then width = parent:getWidth() * 0.8 end
    if not height then height = parent:getHeight() * 0.6 end
    if not text then text = "" end
    parent[name] = ISTextEntryBox:new(text, x, y, width, height)
    parent[name]:initialise()
    parent[name]:instantiate()
    parent[name]:setMultipleLine(true)
    parent[name].javaObject:setMaxLines(10)
    parent[name].javaObject:setMaxTextLength(500)
    parent:addChild(parent[name])
    parent[name]:setEditable(true) 
    return parent[name]
end

function UserInterface.childSlider(parent, name, callback, x, y, width, height, default_value)
    if not x then x = 5 end
    if not y then y = 25 end
    if not width then width = parent:getWidth() * 0.95 end
    if not height then height = 20 end
    if not default_value then default_value = 0.0 end
    parent[name] = ISSliderPanel:new(x, y, width, height, parent, nil)
    parent[name]:initialise()
    parent[name]:instantiate()
    parent[name].valueLabel = true
    parent[name]:setValues(0.0, 100.0, 0.1, 1.0)
    parent[name]:setCurrentValue(default_value, true)
    local old = parent[name].doOnValueChange
    parent[name].doOnValueChange = function(self, _newValue)
        old(self, _newValue)
        return callback(parent, name)
    end
    parent:addChild(parent[name])
    return parent[name]
end
