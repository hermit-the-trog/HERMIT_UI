
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================
-- File [ override.lua ] : Context Menu Facilities

-- Inventory [ .../override ]
-- 1. Override.singlePrototype(inner_function,prototype,function_name)
-- 2. Override.multiplePrototypes(inner_function,function_name,prototype_array_table)
-- --------------------------- LIB | VANILLA --------------------------
-- local PARENT_DIR = PLS DEFINE ME !!!
-- local Override = require(PARENT_DIR.."override")

local Override = {}

--
-- ====================================================================
--

function Override.singlePrototype(inner_function,prototype,function_name) -- [testing]
    if not prototype then return nil end
    if not prototype[function_name] then return nil end
    local old = prototype[function_name]
    prototype[function_name] = function(self)
        return inner_function(old,self)
    end
end

function Override.multiplePrototypes(inner_function,function_name,prototype_array_table) -- [testing]
    for i,v in ipairs(prototype_array_table) do 
        Override.singlePrototype(inner_function, v,function_name)
    end
end

--
-- ====================================================================
--

return Override
