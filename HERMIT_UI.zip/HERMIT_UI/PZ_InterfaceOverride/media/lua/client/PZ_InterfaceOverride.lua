
-- ====================================================================
-- oZumbiAnalitico : 
-- 1. youtube ; https://www.youtube.com/@oZumbiAnalitico
-- 2. steam workshop ; https://steamcommunity.com/id/ozumbianalitico/myworkshopfiles/
-- 3. email ; ericyuta@gmail.com
-- ====================================================================

local PARENT_DIR = "Toolbox_PZIntOv/"

--
-- ====================================================================
-- Requires

local UserInterface = require(PARENT_DIR.."user_interface")
local ContextMenu = require(PARENT_DIR.."context_menu")
local ContextMenu2 = require(PARENT_DIR.."2_context_menu")
local Data = require(PARENT_DIR.."data")
local Override = require(PARENT_DIR.."override")

--
-- ====================================================================
-- File-Variables

local options = nil
Data.init( function() 
    options = Data.regTableData("PZ_InterfaceOverride_Options")
    if options.show_hud_buttons == nil then 
        options.show_hud_buttons = true
    end
    if options.background_alpha == nil then 
        options.background_alpha = 0.2
    end
    --
    if options.border_color_red == nil then 
       options.border_color_red = 0.7 
    end
    if options.border_color_green == nil then 
       options.border_color_green = 0.7
    end
    if options.border_color_blue == nil then 
        options.border_color_blue = 0.7
    end
    --
    if options.back_color_red == nil then 
       options.back_color_red = 0.0 
    end
    if options.back_color_green == nil then 
       options.back_color_green = 0.0
    end
    if options.back_color_blue == nil then 
        options.back_color_blue = 0.0
    end
    
    if options.minimap_transparency==nil then
        options.minimap_transparency = false
    end
    
    --o.borderColor = {r=1, g=1, b=1, a=0.15};
	--o.backgroundColor = {r=0.1, g=0.1, b=0.1, a=0.7};
    
    -- context menu
    if options.background_alpha_cm == nil then 
        options.background_alpha_cm = 0.7
    end
    if options.back_color_red_cm == nil then 
        options.back_color_red_cm = 0.1
    end
    if options.back_color_green_cm == nil then 
        options.back_color_green_cm = 0.1
    end
    if options.back_color_blue_cm == nil then 
        options.back_color_blue_cm = 0.1
    end
    if options.font_size_cm == nil then 
        options.font_size_cm = "medium"
    end

    --
    if options.border_temperature == nil then 
        options.border_temperature = false
    end
    --
    if options.auto_hide_hud_buttons == nil then 
        options.auto_hide_hud_buttons = false
    end
    --
    if options.auto_hide_hotbar == nil then 
        options.auto_hide_hotbar = false
    end
end )
-- 
local callback_dictionary = {}

--
-- ====================================================================
-- Hud Buttons Overrides

local mouseX = nil
local mouseY = nil
--
local function is_mouse_pointer_on_left_side()
    mouseX = getMouseX()
    return ( (mouseX ~= nil) and (mouseX <= 50) )
end
--
local function is_mouse_pointer_on_down_side(height) 
    if not height then height = 50 end
    mouseY = getMouseY()
    return ( (mouseY ~= nil) and (mouseY >= getCore():getScreenHeight() - height ) )
end

-- 1. Hud Buttons Visibility
-- 2. Hotbar Visibility
local old_ISEquippedItem_prerender = ISEquippedItem.prerender
local b_isNotAiming = true
local PLAYER = nil
function ISEquippedItem:prerender()
    old_ISEquippedItem_prerender(self)
    if not PLAYER then PLAYER = getPlayer() end
    b_isNotAiming = ( PLAYER and (not PLAYER:isAiming() ) )
    UserInterface.foreachHudButton( function(ui) 
        if not ui then return nil end -- continue
        if not options.auto_hide_hud_buttons then 
            ui:setVisible(options.show_hud_buttons)
        else 
            ui:setVisible( is_mouse_pointer_on_left_side() and b_isNotAiming )
        end
        return nil -- end iteration
    end )
    local HOTBAR = getPlayerHotbar(0)
    if HOTBAR and options.auto_hide_hotbar then 
        HOTBAR:setVisible( is_mouse_pointer_on_down_side( HOTBAR:getHeight() ) and b_isNotAiming )
    else 
        HOTBAR:setVisible( true )
    end
end

--
-- ====================================================================
-- User Interfaces and Prerender Overrides

-- local getTempColor_object_1 = nil
local getTempColor_object_2 = nil
--
local function getTempColor(temp_min, blue_cyan, cyan_green, green_yellow, temp_max) -- [testing]
    if not temp_min then temp_min = 14 end
    if not blue_cyan then blue_cyan = 20 end
    if not cyan_green then cyan_green = 24 end
    if not green_yellow then green_yellow = 26 end
    if not temp_max then temp_max = 30 end
    local R = nil
    local G = nil 
    local B = nil
    local scale = nil
    local cte = nil
    -- getTempColor_object_1 = getTempColor_object_1 or getPlayer():getBodyDamage():getThermoregulator()
    getTempColor_object_2 = getTempColor_object_2 or getPlayer()
    --local world_temp = getTempColor_object_1:getTemperatureAirAndWind()
    local player_temp = getTempColor_object_2:getTemperature()
    local temp = (player_temp - 13) + 3*(player_temp-37)
    --getWorld():getGlobalTemperature() --getSpecificPlayer(0):getTemperature()
    if temp <= blue_cyan then -- (0,0,255) -> (0,255,255)
        R = 0
        B = 1
        -- G(t) = scale*t+cte
        -- 255 = scale*blue_cyan+cte
        -- 0 = scale*temp_min+cte
        -- 255 = scale*(blue_cyan-temp_min)
        -- scale = 255/(blue_cyan-temp_min)
        -- cte = 255 - scale*blue_cyan
        scale = 1/(blue_cyan-temp_min)
        cte = 1 - scale*blue_cyan
        G = scale*temp + cte
    elseif temp <= cyan_green then -- (0,255,255) -> (0,255,0)
        R = 0
        G = 1
        -- B(t) = scale*t+cte
        -- 255 = scale*blue_cyan+cte
        -- 0 = scale*cyan_green+cte
        -- 255 = scale*(blue_cyan-cyan_green)
        -- scale = 255/(blue_cyan-cyan_green)
        -- cte = 255 - scale*blue_cyan
        scale = 1/(blue_cyan-cyan_green)
        cte = 1 - scale*blue_cyan
        B = scale*temp+cte
    elseif temp <= green_yellow then -- (0,255,0) -> (255,255,0)
        B = 0
        G = 1
        -- R(t) = scale*t+cte
        -- 0 = scale*cyan_green+cte
        -- 255 = scale*green_yellow+cte
        -- 255 = scale*(green_yellow - cyan_green)
        -- cte = 255 - scale*green_yellow
        scale = 1/(green_yellow - cyan_green)
        cte = 1 - scale*green_yellow
        R = scale*temp+ cte
    elseif temp <= temp_max then -- (255,255,0) -> (255,0,0)
        R = 1
        B = 0
        -- G(t) = scale*t+cte
        -- 255 = scale*green_yellow+cte
        -- 0 = scale*temp_max+cte
        -- 255 = scale*(green_yellow - temp_max)
        -- scale = 255/(green_yellow - temp_max)
        -- cte = 255 - scale*green_yellow
        scale = 1/(green_yellow - temp_max)
        cte = 1 - scale*green_yellow
        G = scale*temp+cte
    else 
        R = 1
        G = 0
        B = 0
    end
    return R,G,B
end

local PANEL_alpha = nil
local PANEL_border_color = nil
local PANEL_background_color = nil
-- context menu
local PANEL_alpha_context_menu = nil
local PANEL_background_color_context_menu = nil
UserInterface.inGame( function(screen_width,screen_height,core)
    -- transparency user interface
    PANEL_alpha = UserInterface.window("PANEL_alpha", nil,nil,300,70)
    local PANEL_alpha_SLIDER_1 = UserInterface.childSlider( PANEL_alpha, "set_alpha", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.background_alpha = parent[name]:getCurrentValue()/100.0
    end, nil,nil,nil,nil, options.background_alpha*100 ) 
    -- border color
    PANEL_border_color = UserInterface.window("PANEL_border_color", nil,nil,300,150)
    local PANEL_border_color_SLIDER_red = UserInterface.childSlider( PANEL_border_color, "set_border_red", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.border_color_red = parent[name]:getCurrentValue()/100.0
    end, nil,nil,nil,nil, options.border_color_red*100 ) 
    local PANEL_border_color_SLIDER_green = UserInterface.childSlider( PANEL_border_color, "set_border_green", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.border_color_green = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_border_color_SLIDER_red:getY() + PANEL_border_color_SLIDER_red:getHeight() + 10 ,nil,nil, options.border_color_green*100 ) 
    local PANEL_border_color_SLIDER_blue = UserInterface.childSlider( PANEL_border_color, "set_border_blue", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.border_color_blue = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_border_color_SLIDER_green:getY() + PANEL_border_color_SLIDER_green:getHeight() + 10 ,nil,nil, options.border_color_blue*100 ) 
    -- background color
    PANEL_background_color = UserInterface.window("PANEL_background_color", nil,nil,300,150)
    local PANEL_background_color_SLIDER_red = UserInterface.childSlider( PANEL_background_color, "set_back_red", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_red = parent[name]:getCurrentValue()/100.0
    end, nil,nil,nil,nil, options.back_color_red*100 ) 
    local PANEL_background_color_SLIDER_green = UserInterface.childSlider( PANEL_background_color, "set_back_green", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_green = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_background_color_SLIDER_red:getY() + PANEL_background_color_SLIDER_red:getHeight() + 10 ,nil,nil, options.back_color_green*100 ) 
    local PANEL_background_color_SLIDER_blue = UserInterface.childSlider( PANEL_background_color, "set_back_blue", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_blue = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_background_color_SLIDER_green:getY() + PANEL_background_color_SLIDER_green:getHeight() + 10 ,nil,nil, options.back_color_blue*100 ) 
    -- transparency for context menu
    PANEL_alpha_context_menu = UserInterface.window("PANEL_alpha_context_menu", nil,nil,300,70)
    UserInterface.childSlider( PANEL_alpha_context_menu, "set_alpha_context_menu", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.background_alpha_cm = parent[name]:getCurrentValue()/100.0
    end, nil,nil,nil,nil, options.background_alpha_cm*100 )
    -- background color for context menu
    PANEL_background_color_context_menu = UserInterface.window("PANEL_background_color_context_menu", nil,nil,300,150)
    local PANEL_background_color_SLIDER_red_cm = UserInterface.childSlider( PANEL_background_color_context_menu, "set_back_red_cm", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_red_cm = parent[name]:getCurrentValue()/100.0
    end, nil,nil,nil,nil, options.back_color_red_cm*100 ) 
    local PANEL_background_color_SLIDER_green_cm = UserInterface.childSlider( PANEL_background_color_context_menu, "set_back_green_cm", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_green_cm = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_background_color_SLIDER_red_cm:getY() + PANEL_background_color_SLIDER_red_cm:getHeight() + 10 ,nil,nil, options.back_color_green_cm*100 ) 
    local PANEL_background_color_SLIDER_blue_cm = UserInterface.childSlider( PANEL_background_color_context_menu, "set_back_blue_cm", function(parent, name)
        if not parent[name]:isVisible() then return nil end
        options.back_color_blue_cm = parent[name]:getCurrentValue()/100.0
    end, nil, PANEL_background_color_SLIDER_green_cm:getY() + PANEL_background_color_SLIDER_green_cm:getHeight() + 10 ,nil,nil, options.back_color_blue_cm*100 ) 
    -- overrides
    Override.multiplePrototypes( function(old, self) 
        -- background override
        self.backgroundColor.r = options.back_color_red
        self.backgroundColor.g = options.back_color_green
        self.backgroundColor.b = options.back_color_blue
        self.backgroundColor.a = options.background_alpha
        -- border override
        if options.border_temperature then 
            self.borderColor.r, self.borderColor.g, self.borderColor.b = getTempColor()
        else 
            self.borderColor.r = options.border_color_red
            self.borderColor.g = options.border_color_green
            self.borderColor.b = options.border_color_blue
        end
        self.borderColor.a = 0.8
        -- 
        old(self)
    end , "prerender", 
    { 
        ISInventoryPage, 
        ISFitnessUI, 
        ISUIWriteJournal, 
        ISFishingUI, 
        ISPanelJoypad, 
        ISPanel, 
        ISCollapsableWindow,
        ISCollapsableWindowJoypad,
        ISMiniMapOuter
    } )

    -- override for context menu
    ContextMenu2.ContextPrerender( function(C,B,F, context)
        B(options.border_color_red,options.border_color_green,options.border_color_blue,0.8)
        C(options.back_color_red_cm,options.back_color_green_cm,options.back_color_blue_cm,options.background_alpha_cm)
        F(options.font_size_cm)
    end ) -- o (Color,Border,Font,ISContextMenu_self)
end )

--
-- ====================================================================
-- Mini Map Override

--[[
function MapUtils.overlayPaper(mapUI)
	local mapAPI = mapUI.javaObject:getAPIv1()
	local styleAPI = mapAPI:getStyleAPI()
	local layer = styleAPI:newTextureLayer("paper")
	layer:setMinZoom(0.00)
	local x1 = mapAPI:getMinXInSquares()
	local y1 = mapAPI:getMinYInSquares()
	local x2 = mapAPI:getMaxXInSquares() + 1
	local y2 = mapAPI:getMaxYInSquares() + 1
	layer:setBoundsInSquares(x1, y1, x2, y2)
	layer:setTile(true)
	layer:setUseWorldBounds(true)
	--layer:addFill(14.00, 128, 128, 128, 0)
	--layer:addFill(15.00, 128, 128, 128, 32)
	--layer:addFill(15.00, 255, 255, 255, 32)
	--layer:addTexture(0.00, "media/white.png")
	--layer:addTexture(15.00, "media/white.png")
	--layer:addTexture(15.00, "media/textures/worldMap/Paper.png")
end
--]]

Override.singlePrototype( function(old,self) 
    local mapAPI = self.inner.mapAPI
    local r,g,b = 219/255, 215/255, 192/255
    if options.minimap_transparency==true then
        mapAPI:setBackgroundRGBA(r, g, b, options.background_alpha)
        mapAPI:setUnvisitedRGBA(r * 0.915, g * 0.915, b * 0.915, options.background_alpha)
        mapAPI:setUnvisitedGridRGBA(r * 0.777, g * 0.777, b * 0.777, options.background_alpha)
    else
        mapAPI:setBackgroundRGBA(r, g, b, 1.0)
        mapAPI:setUnvisitedRGBA(r * 0.915, g * 0.915, b * 0.915, 1.0)
        mapAPI:setUnvisitedGridRGBA(r * 0.777, g * 0.777, b * 0.777, 1.0)
    end
    old(self)
end, ISMiniMapOuter ,"render")

--
-- ====================================================================
-- Context Menu

-- Hud Button Callbacks
callback_dictionary["Toggle - Hud Buttons"] = function()
    options.show_hud_buttons = not options.show_hud_buttons
end

callback_dictionary["Toggle - Auto Hide Hud Buttons"] = function() 
    options.auto_hide_hud_buttons = not options.auto_hide_hud_buttons
    getPlayer():Say("Auto Hide Hud Buttons: "..tostring(options.auto_hide_hud_buttons))
end 

callback_dictionary["Toggle - Auto Hide Hotbar"] = function() 
    options.auto_hide_hotbar = not options.auto_hide_hotbar
    getPlayer():Say("Auto Hide Hotbar: "..tostring(options.auto_hide_hotbar))
end 

callback_dictionary["Toggle - Minimap Transparency"] = function() 
    options.minimap_transparency = not options.minimap_transparency
end

callback_dictionary["Toggle - Border Temperature"] = function() 
    options.border_temperature = not options.border_temperature
end

-- Background
callback_dictionary["Set - Transparency"] = function() 
    PANEL_alpha:setVisible( not PANEL_alpha:isVisible() )
end

callback_dictionary["Set - Background RGB"] = function() 
    PANEL_background_color:setVisible( not PANEL_background_color:isVisible() )
end

-- Border Color
-- "Set Border RGB Values"
callback_dictionary["Set - Border RGB"] = function() 
    PANEL_border_color:setVisible( not PANEL_border_color:isVisible() )
end

-- Context Menu
callback_dictionary["Set - Context Menu Transparency"] = function() 
    PANEL_alpha_context_menu:setVisible( not PANEL_alpha_context_menu:isVisible() )
end
callback_dictionary["Set - Context Menu Background RGB"] = function() 
    PANEL_background_color_context_menu:setVisible( not PANEL_background_color_context_menu:isVisible() )
end
callback_dictionary["Context Menu - Small"] = function()
    options.font_size_cm = "small"
end
callback_dictionary["Context Menu - Medium"] = function() 
    options.font_size_cm = "medium"
end
callback_dictionary["Context Menu - Large"] = function() 
    options.font_size_cm = "large"
end

--
callback_dictionary["Reset"] = function() 
    Data.resetTableData("PZ_InterfaceOverride_Options")
    options = Data.regTableData("PZ_InterfaceOverride_Options")
    if options.show_hud_buttons == nil then 
        options.show_hud_buttons = true
    end
    if options.background_alpha == nil then 
        options.background_alpha = 0.2
    end
    --
    if options.border_color_red == nil then 
       options.border_color_red = 0.7 
    end
    if options.border_color_green == nil then 
       options.border_color_green = 0.7
    end
    if options.border_color_blue == nil then 
        options.border_color_blue = 0.7
    end
    --
    if options.back_color_red == nil then 
       options.back_color_red = 0.0 
    end
    if options.back_color_green == nil then 
       options.back_color_green = 0.0
    end
    if options.back_color_blue == nil then 
        options.back_color_blue = 0.0
    end
    
    if options.minimap_transparency==nil then
        options.minimap_transparency = false
    end
    
    -- context menu
    if options.background_alpha_cm == nil then 
        options.background_alpha_cm = 0.7
    end
    if options.back_color_red_cm == nil then 
        options.back_color_red_cm = 0.1
    end
    if options.back_color_green_cm == nil then 
        options.back_color_green_cm = 0.1
    end
    if options.back_color_blue_cm == nil then 
        options.back_color_blue_cm = 0.1
    end
    if options.font_size_cm == nil then 
        options.font_size_cm = "medium"
    end

    --
    if options.border_temperature == nil then 
        options.border_temperature = false
    end
end

-- 
ContextMenu2.IWorld( function(Interface) 
    Interface:Structure( { 
        { name="UI options", 
            { name = "Hide UI Components",
                "Toggle - Hud Buttons",
                "Toggle - Auto Hide Hud Buttons"
                --"Toggle - Auto Hide Hotbar"            
            }, 
            { name = "Window Border",
                "Toggle - Border Temperature",
                "Set - Border RGB"
            },
            { name = "Window Background",
                "Set - Background RGB",
                "Set - Transparency"
            },
            { name = "Context Menu",
                "Set - Context Menu Transparency",
                "Set - Context Menu Background RGB",
                { name = "Set - Context Menu Font", 
                    "Context Menu - Small",
                    "Context Menu - Medium",
                    "Context Menu - Large"
                }
            },
            "Toggle - Minimap Transparency",            
            "Reset"
            }
    }, callback_dictionary )
    return true
end )













